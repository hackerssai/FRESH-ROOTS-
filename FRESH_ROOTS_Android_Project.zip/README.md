# FRESH ROOTS Android app starter

This is an Expo / React Native project for an Android and iOS app. It is **source code, not a compiled APK**.

## What is included
- Premium earth-tone FRESH ROOTS interface
- Home, Shop, Basket and Profile tabs
- Sample fruits and vegetables catalogue with search and category filters
- Working demo basket and quantity controls
- Tap feedback messages and responsive mobile layout

## Important demo limitations
Product names and prices are sample content. Checkout does not take payment or place orders. Customer accounts, live inventory, delivery scheduling, maps, chat, push notifications, AI services and admin tools require backend services and configuration before a real launch.

## Build an Android APK
You need a computer with Node.js installed and an Expo account:
1. Extract this ZIP.
2. Open a terminal in the extracted `fresh_roots_android_project` folder.
3. Run `npm install`.
4. Install EAS CLI: `npm install -g eas-cli`.
5. Sign in: `eas login`.
6. Configure: `eas build:configure`.
7. Create an installable APK with EAS Build. In `eas.json`, use an Android build profile with `android.buildType` set to `apk`, then run `eas build -p android --profile preview`.
8. When the cloud build finishes, download the APK from the build page and install it on your Android phone.

This project has not been compiled or tested as an APK in this environment. A real APK must be built and checked before distribution.
