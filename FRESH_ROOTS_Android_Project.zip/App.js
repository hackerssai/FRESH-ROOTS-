import React, { useMemo, useState } from 'react';
import { SafeAreaView, View, Text, TextInput, ScrollView, TouchableOpacity, StatusBar, StyleSheet } from 'react-native';

const products = [
  {id:'1',name:'Tomatoes',category:'Vegetables',price:32,unit:'kg',emoji:'🍅',tag:'Daily fresh'},
  {id:'2',name:'Fresh Spinach',category:'Vegetables',price:25,unit:'bunch',emoji:'🥬',tag:'Leafy greens'},
  {id:'3',name:'Carrots',category:'Vegetables',price:48,unit:'kg',emoji:'🥕',tag:'Farm fresh'},
  {id:'4',name:'Potatoes',category:'Vegetables',price:30,unit:'kg',emoji:'🥔',tag:'Kitchen essential'},
  {id:'5',name:'Apples',category:'Fruits',price:140,unit:'kg',emoji:'🍎',tag:'Crisp & sweet'},
  {id:'6',name:'Bananas',category:'Fruits',price:55,unit:'dozen',emoji:'🍌',tag:'Naturally sweet'},
  {id:'7',name:'Oranges',category:'Fruits',price:85,unit:'kg',emoji:'🍊',tag:'Juicy pick'},
  {id:'8',name:'Watermelon',category:'Fruits',price:38,unit:'kg',emoji:'🍉',tag:'Seasonal pick'}
];

export default function App() {
  const [tab,setTab] = useState('Home');
  const [category,setCategory] = useState('All');
  const [search,setSearch] = useState('');
  const [cart,setCart] = useState({});
  const [notice,setNotice] = useState('');
  const items = useMemo(()=>products.filter(p=>(category==='All'||p.category===category)&&p.name.toLowerCase().includes(search.toLowerCase())),[category,search]);
  const count = Object.values(cart).reduce((a,b)=>a+b,0);
  const total = products.reduce((s,p)=>s+(cart[p.id]||0)*p.price,0);
  const add = p => {setCart(c=>({...c,[p.id]:(c[p.id]||0)+1}));setNotice(p.name+' added to your basket');};
  const change = (id,n) => setCart(c=>({...c,[id]:Math.max(0,(c[id]||0)+n)}));
  const go = t => {setTab(t);setNotice('');};
  const ProductCard = ({p}) => <View style={s.product}>
    <View style={s.productArt}><Text style={{fontSize:42}}>{p.emoji}</Text><Text style={s.tag}>{p.tag}</Text></View>
    <Text style={s.productName}>{p.name}</Text><Text style={s.muted}>₹{p.price} / {p.unit}</Text>
    <TouchableOpacity accessibilityRole="button" style={s.addBtn} onPress={()=>add(p)}><Text style={s.addText}>＋ Add</Text></TouchableOpacity>
  </View>;
  return <SafeAreaView style={s.safe}>
    <StatusBar barStyle="dark-content" backgroundColor="#F5F2E8"/>
    <View style={s.header}><View><Text style={s.brand}>FRESH <Text style={{color:'#D18A42'}}>ROOTS</Text></Text><Text style={s.subbrand}>GOOD FOOD. ROOTED IN FRESHNESS.</Text></View>
      <TouchableOpacity style={s.cartPill} onPress={()=>go('Basket')}><Text style={s.cartText}>🛒 {count}</Text></TouchableOpacity></View>
    <ScrollView contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
      {tab==='Home' && <>
        <View style={s.hero}><Text style={s.eyebrow}>FRESH PICKS, EVERY DAY</Text><Text style={s.heroTitle}>A little greener.{'\n'}A lot fresher.</Text><Text style={s.heroBody}>Discover everyday vegetables and fruits for your kitchen.</Text><TouchableOpacity style={s.heroBtn} onPress={()=>go('Shop')}><Text style={s.heroBtnText}>Explore produce  →</Text></TouchableOpacity><Text style={s.heroEmoji}>🥑 🥦 🍊</Text></View>
        <Text style={s.sectionTitle}>Shop by category</Text><View style={s.categoryRow}><TouchableOpacity style={s.category} onPress={()=>{setCategory('Vegetables');go('Shop')}}><Text style={s.categoryEmoji}>🥬</Text><Text style={s.categoryText}>Vegetables</Text></TouchableOpacity><TouchableOpacity style={s.category} onPress={()=>{setCategory('Fruits');go('Shop')}}><Text style={s.categoryEmoji}>🍎</Text><Text style={s.categoryText}>Fruits</Text></TouchableOpacity></View>
        <View style={s.sectionRow}><Text style={s.sectionTitle}>Popular picks</Text><TouchableOpacity onPress={()=>go('Shop')}><Text style={s.link}>View all</Text></TouchableOpacity></View>
        <View style={s.grid}>{products.slice(0,4).map(p=><ProductCard key={p.id} p={p}/>)}</View>
        <View style={s.note}><Text style={s.noteTitle}>Fresh choices, made simple.</Text><Text style={s.muted}>Browse the sample catalogue and build your basket. Product availability and prices are demo content.</Text></View>
      </>}
      {tab==='Shop' && <><Text style={s.pageTitle}>Shop fresh</Text><Text style={s.muted}>Choose your everyday favourites.</Text>
        <TextInput value={search} onChangeText={setSearch} placeholder="Search vegetables and fruits" placeholderTextColor="#8A8F80" style={s.search}/>
        <View style={s.filters}>{['All','Vegetables','Fruits'].map(c=><TouchableOpacity key={c} onPress={()=>setCategory(c)} style={[s.filter,category===c&&s.filterOn]}><Text style={[s.filterText,category===c&&s.filterTextOn]}>{c}</Text></TouchableOpacity>)}</View>
        <View style={s.grid}>{items.map(p=><ProductCard key={p.id} p={p}/>)}</View>
      </>}
      {tab==='Basket' && <><Text style={s.pageTitle}>Your basket</Text><Text style={s.muted}>A fresh start for your next meal.</Text>
        {products.filter(p=>cart[p.id]).map(p=><View key={p.id} style={s.basketRow}><Text style={{fontSize:30}}>{p.emoji}</Text><View style={{flex:1}}><Text style={s.productName}>{p.name}</Text><Text style={s.muted}>₹{p.price} / {p.unit}</Text></View><View style={s.qty}><TouchableOpacity onPress={()=>change(p.id,-1)}><Text style={s.qtyText}>−</Text></TouchableOpacity><Text style={s.qtyNum}>{cart[p.id]}</Text><TouchableOpacity onPress={()=>change(p.id,1)}><Text style={s.qtyText}>＋</Text></TouchableOpacity></View></View>)}
        {count===0?<Text style={s.empty}>Your basket is empty. Explore fresh produce in Shop.</Text>:<View style={s.totalBox}><Text style={s.totalLabel}>Estimated subtotal</Text><Text style={s.total}>₹{total}</Text><Text style={s.muted}>Demo basket only. Checkout and online payments are not connected.</Text><TouchableOpacity style={s.checkout} onPress={()=>setNotice('Checkout is a demo preview. No order or payment was placed.')}><Text style={s.checkoutText}>Continue (demo)</Text></TouchableOpacity></View>}
      </>}
      {tab==='Profile' && <><Text style={s.pageTitle}>Your profile</Text><View style={s.profileCard}><Text style={{fontSize:38}}>🌱</Text><Text style={s.sectionTitle}>Welcome to FRESH ROOTS</Text><Text style={s.muted}>Your account area will be available when sign-in is connected.</Text></View><Text style={s.sectionTitle}>About this preview</Text><Text style={s.muted}>This is an installable app starter with sample produce. Live accounts, inventory, delivery scheduling, maps, chat, notifications and payments need backend services and owner setup.</Text></>}
      {!!notice&&<TouchableOpacity onPress={()=>setNotice('')} style={s.toast}><Text style={s.toastText}>{notice}  ✕</Text></TouchableOpacity>}
    </ScrollView>
    <View style={s.nav}>{[['Home','⌂'],['Shop','▦'],['Basket','🛒'],['Profile','○']].map(([t,i])=><TouchableOpacity key={t} onPress={()=>go(t)} style={s.navItem}><Text style={[s.navIcon,tab===t&&s.navActive]}>{i}</Text><Text style={[s.navLabel,tab===t&&s.navActive]}>{t}</Text></TouchableOpacity>)}</View>
  </SafeAreaView>;
}

const s=StyleSheet.create({
 safe:{flex:1,backgroundColor:'#F5F2E8'},header:{paddingHorizontal:20,paddingVertical:15,flexDirection:'row',justifyContent:'space-between',alignItems:'center',backgroundColor:'#F5F2E8'},brand:{fontSize:23,fontWeight:'900',letterSpacing:1.4,color:'#244C37'},subbrand:{fontSize:8,letterSpacing:1.6,color:'#777D6C',marginTop:2},cartPill:{backgroundColor:'#E5EBDD',paddingHorizontal:14,paddingVertical:9,borderRadius:22},cartText:{fontWeight:'800',color:'#244C37'},content:{padding:18,paddingBottom:28},hero:{backgroundColor:'#244C37',borderRadius:25,padding:23,minHeight:250,overflow:'hidden'},eyebrow:{color:'#D8B77B',fontSize:10,fontWeight:'800',letterSpacing:2},heroTitle:{fontSize:34,lineHeight:39,fontWeight:'900',color:'#FFF9EB',marginTop:14},heroBody:{color:'#E3E9D9',fontSize:13,lineHeight:19,marginTop:9,maxWidth:235},heroBtn:{backgroundColor:'#E8B96E',alignSelf:'flex-start',paddingHorizontal:16,paddingVertical:11,borderRadius:18,marginTop:18},heroBtnText:{color:'#233F2D',fontWeight:'800'},heroEmoji:{position:'absolute',right:8,bottom:17,fontSize:25},sectionTitle:{fontSize:18,fontWeight:'900',color:'#263E2E',marginTop:23,marginBottom:12},categoryRow:{flexDirection:'row',gap:12},category:{flex:1,backgroundColor:'#E8EBDD',borderRadius:18,padding:17,alignItems:'center'},categoryEmoji:{fontSize:30},categoryText:{color:'#2E4C38',fontWeight:'800',marginTop:7},sectionRow:{flexDirection:'row',justifyContent:'space-between',alignItems:'center'},link:{color:'#A66D32',fontWeight:'800'},grid:{flexDirection:'row',flexWrap:'wrap',justifyContent:'space-between'},product:{width:'48%',backgroundColor:'#FFFEF9',borderRadius:17,padding:11,marginBottom:12,borderWidth:1,borderColor:'#E9E6D9'},productArt:{height:105,backgroundColor:'#F0F2E6',borderRadius:12,alignItems:'center',justifyContent:'center'},tag:{fontSize:9,color:'#68765D',marginTop:5,fontWeight:'700'},productName:{fontSize:14,fontWeight:'900',color:'#263E2E',marginTop:9},muted:{fontSize:11,color:'#777D70',lineHeight:17,marginTop:4},addBtn:{backgroundColor:'#244C37',padding:9,borderRadius:11,alignItems:'center',marginTop:10},addText:{color:'#FFF9EB',fontWeight:'800',fontSize:12},note:{backgroundColor:'#E8EBDD',padding:17,borderRadius:17,marginTop:8},noteTitle:{fontSize:15,fontWeight:'900',color:'#2A4B35'},pageTitle:{fontSize:27,fontWeight:'900',color:'#263E2E',marginTop:5},search:{backgroundColor:'#FFFEF9',borderWidth:1,borderColor:'#E1E3D6',borderRadius:14,padding:14,marginTop:18,color:'#263E2E'},filters:{flexDirection:'row',gap:8,marginVertical:15},filter:{paddingHorizontal:15,paddingVertical:9,borderRadius:20,backgroundColor:'#E7EBDD'},filterOn:{backgroundColor:'#244C37'},filterText:{color:'#39523E',fontWeight:'700',fontSize:12},filterTextOn:{color:'#FFF9EB'},basketRow:{flexDirection:'row',alignItems:'center',gap:12,backgroundColor:'#FFFEF9',padding:13,borderRadius:15,marginTop:12},qty:{flexDirection:'row',alignItems:'center',gap:12},qtyText:{fontSize:20,color:'#244C37',fontWeight:'900'},qtyNum:{fontWeight:'800',color:'#263E2E'},empty:{padding:25,textAlign:'center',color:'#777D70',lineHeight:22},totalBox:{backgroundColor:'#E8EBDD',padding:18,borderRadius:18,marginTop:20},totalLabel:{color:'#596B57',fontWeight:'700'},total:{fontSize:30,fontWeight:'900',color:'#244C37',marginVertical:5},checkout:{backgroundColor:'#244C37',padding:14,borderRadius:13,alignItems:'center',marginTop:14},checkoutText:{color:'white',fontWeight:'900'},profileCard:{backgroundColor:'#FFFEF9',borderRadius:18,padding:20,alignItems:'center',marginTop:18},nav:{flexDirection:'row',justifyContent:'space-around',backgroundColor:'#FFFEF9',paddingTop:10,paddingBottom:12,borderTopWidth:1,borderColor:'#E8E5D9'},navItem:{alignItems:'center',minWidth:55},navIcon:{fontSize:21,color:'#8A9284'},navLabel:{fontSize:10,color:'#8A9284',marginTop:3,fontWeight:'700'},navActive:{color:'#244C37',fontWeight:'900'},toast:{backgroundColor:'#DDE8D6',padding:13,borderRadius:12,marginTop:15},toastText:{color:'#244C37',fontWeight:'700',fontSize:12}
});
